var searchData=
[
  ['file',['File',['../interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#ac40f5cfafac5c4c6b53bfdd67794d3f2',1,'MyLib.Shared.Database.IDatabaseFile.File()'],['../class_my_lib_1_1_shared_1_1_database_1_1_database_file_base.html#aad2709f8745d055f7964182837659019',1,'MyLib.Shared.Database.DatabaseFileBase.File()']]]
];
