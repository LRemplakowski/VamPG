var searchData=
[
  ['prefsname',['PrefsName',['../class_my_lib_1_1_editor_tools_1_1_database_window_editor.html#ab7b37f7789e691c4489d26194f6fd171',1,'MyLib::EditorTools::DatabaseWindowEditor']]]
];
