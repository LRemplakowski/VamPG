var searchData=
[
  ['data',['data',['../class_my_lib_1_1_shared_1_1_database_1_1_database_file_base.html#a157c0d64b65c0a9622547c6cbdcf0aee',1,'MyLib::Shared::Database::DatabaseFileBase']]]
];
