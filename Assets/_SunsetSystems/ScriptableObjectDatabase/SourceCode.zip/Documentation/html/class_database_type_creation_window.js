var class_database_type_creation_window =
[
    [ "CreateDatabaseType", "class_database_type_creation_window.html#a0afd11c6babdaa12362f6f561a7d262d", null ],
    [ "OnDestroy", "class_database_type_creation_window.html#acbbaa4ce767322e65dee1af914e96d83", null ],
    [ "OnGUI", "class_database_type_creation_window.html#af7076683705a04fa1424d8154592a69b", null ],
    [ "OnSelectionChange", "class_database_type_creation_window.html#a8a794842ca43b1d051cfc2649e396a9e", null ],
    [ "OpenDatabaseTypeWindow", "class_database_type_creation_window.html#aa201893119151f032cb4ef77c0ce0159", null ],
    [ "EditorSavePath", "class_database_type_creation_window.html#a24b20e69ede6daeb562d41ea84fbb63c", null ],
    [ "RuntimeSavePath", "class_database_type_creation_window.html#a4c3ce4841fd61479353ae8e3485b732a", null ]
];