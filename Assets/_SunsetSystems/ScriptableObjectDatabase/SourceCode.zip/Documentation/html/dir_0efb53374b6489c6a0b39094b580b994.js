var dir_0efb53374b6489c6a0b39094b580b994 =
[
    [ "Editor", "dir_72c053ff52dd6788d5e466cdd115f940.html", "dir_72c053ff52dd6788d5e466cdd115f940" ],
    [ "AssetKey32.cs", "_asset_key32_8cs.html", [
      [ "AssetKey32", "struct_my_lib_1_1_shared_1_1_database_1_1_asset_key32.html", "struct_my_lib_1_1_shared_1_1_database_1_1_asset_key32" ]
    ] ],
    [ "Database.cs", "_database_8cs.html", "_database_8cs" ],
    [ "DatabaseFileBase.cs", "_database_file_base_8cs.html", [
      [ "DatabaseFileBase", "class_my_lib_1_1_shared_1_1_database_1_1_database_file_base.html", "class_my_lib_1_1_shared_1_1_database_1_1_database_file_base" ]
    ] ],
    [ "MainDatabaseCollection.cs", "_main_database_collection_8cs.html", [
      [ "MainDatabaseCollection", "class_main_database_collection.html", "class_main_database_collection" ]
    ] ]
];