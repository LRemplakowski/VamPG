var dir_72c053ff52dd6788d5e466cdd115f940 =
[
    [ "Base", "dir_309890e3638989886506c8f3c6f3b318.html", "dir_309890e3638989886506c8f3c6f3b318" ],
    [ "Tools", "dir_caad2381e4c342297bda731ef7ec39b7.html", "dir_caad2381e4c342297bda731ef7ec39b7" ],
    [ "AddDatabaseButtonTypePopup.cs", "_add_database_button_type_popup_8cs.html", [
      [ "AddDatabaseButtonTypePopup", "class_add_database_button_type_popup.html", "class_add_database_button_type_popup" ]
    ] ],
    [ "AssetEditorWindow.cs", "_asset_editor_window_8cs.html", [
      [ "AssetEditorWindow", "class_asset_editor_window.html", "class_asset_editor_window" ]
    ] ],
    [ "DatabaseTypeCreationWindow.cs", "_database_type_creation_window_8cs.html", [
      [ "DatabaseTypeCreationWindow", "class_database_type_creation_window.html", "class_database_type_creation_window" ]
    ] ]
];