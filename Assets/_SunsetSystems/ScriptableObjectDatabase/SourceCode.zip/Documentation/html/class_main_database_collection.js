var class_main_database_collection =
[
    [ "GetAsset", "class_main_database_collection.html#af15a2cc04104d44a028c91870e80080f", null ],
    [ "GetDatabase", "class_main_database_collection.html#a0d1b23fe2c0082b17e33722b821e62f6", null ],
    [ "GetDatabasesOfType< T >", "class_main_database_collection.html#a9d87663710c566cabb121e6e6390e71e", null ],
    [ "GetUniqueDatabaseId", "class_main_database_collection.html#a0de76d4f8244a12f29eb0f0bb4225989", null ],
    [ "ImportDatabase", "class_main_database_collection.html#ac13d5705bdc4d93f584adaeeb876d3cc", null ],
    [ "RemoveDatabase", "class_main_database_collection.html#adee47f2fccccff5d7c1d1f7c018c7ada", null ],
    [ "hiddenFiles", "class_main_database_collection.html#a3fdb62fd85d850f616474b3679e1f70f", null ],
    [ "visibleFiles", "class_main_database_collection.html#ac93ecc291b6c1accc7f073a86d0e9c6d", null ]
];