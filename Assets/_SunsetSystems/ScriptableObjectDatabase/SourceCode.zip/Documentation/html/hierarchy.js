var hierarchy =
[
    [ "MyLib.Shared.Database.AssetKey32", "struct_my_lib_1_1_shared_1_1_database_1_1_asset_key32.html", null ],
    [ "MyLib.EditorTools.Tools.AssetTools", "class_my_lib_1_1_editor_tools_1_1_tools_1_1_asset_tools.html", null ],
    [ "MyLib.EditorTools.Tools.CustomEditorTools", "class_my_lib_1_1_editor_tools_1_1_tools_1_1_custom_editor_tools.html", null ],
    [ "MyLib.Shared.Database.Database", "class_my_lib_1_1_shared_1_1_database_1_1_database.html", [
      [ "MyLib.Shared.Database.Database< T >", "class_my_lib_1_1_shared_1_1_database_1_1_database.html", null ]
    ] ],
    [ "MyLib.Shared.Database.DatabaseAsset", "class_my_lib_1_1_shared_1_1_database_1_1_database_asset.html", [
      [ "MyLib.Shared.Database.DatabaseAsset< T >", "class_my_lib_1_1_shared_1_1_database_1_1_database_asset.html", null ]
    ] ],
    [ "MyLib.EditorTools.DatabaseManager", "class_my_lib_1_1_editor_tools_1_1_database_manager.html", null ],
    [ "DatabaseWindowEditor", null, [
      [ "MyLib.EditorTools.DatabaseWindowEditor< S, U >", "class_my_lib_1_1_editor_tools_1_1_database_window_editor.html", null ]
    ] ],
    [ "Editor", null, [
      [ "MyLib.EditorTools.DatabaseInspectorBase< S, U >", "class_my_lib_1_1_editor_tools_1_1_database_inspector_base.html", null ]
    ] ],
    [ "EditorWindow", null, [
      [ "AssetEditorWindow", "class_asset_editor_window.html", null ],
      [ "DatabaseTypeCreationWindow", "class_database_type_creation_window.html", null ]
    ] ],
    [ "MyLib.EditorTools.Tools.GUITools", "class_my_lib_1_1_editor_tools_1_1_tools_1_1_g_u_i_tools.html", null ],
    [ "MyLib.Shared.Database.IconAtlas", "class_my_lib_1_1_shared_1_1_database_1_1_icon_atlas.html", null ],
    [ "MyLib.EditorTools.Tools.IconAtlasEditor", "class_my_lib_1_1_editor_tools_1_1_tools_1_1_icon_atlas_editor.html", null ],
    [ "MyLib.Shared.Database.IDatabaseFile", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html", [
      [ "MyLib.Shared.Database.DatabaseFileBase< S, T >", "class_my_lib_1_1_shared_1_1_database_1_1_database_file_base.html", null ]
    ] ],
    [ "PopupWindowContent", null, [
      [ "AddDatabaseButtonTypePopup", "class_add_database_button_type_popup.html", null ]
    ] ],
    [ "ScriptableObject", null, [
      [ "MainDatabaseCollection", "class_main_database_collection.html", null ],
      [ "MyLib.Shared.Database.DatabaseFileBase< S, T >", "class_my_lib_1_1_shared_1_1_database_1_1_database_file_base.html", null ]
    ] ]
];