var namespace_my_lib =
[
    [ "EditorTools", "namespace_my_lib_1_1_editor_tools.html", "namespace_my_lib_1_1_editor_tools" ],
    [ "Shared", "namespace_my_lib_1_1_shared.html", "namespace_my_lib_1_1_shared" ]
];