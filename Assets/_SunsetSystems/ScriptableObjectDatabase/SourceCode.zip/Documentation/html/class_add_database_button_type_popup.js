var class_add_database_button_type_popup =
[
    [ "AddDatabaseButtonTypePopup", "class_add_database_button_type_popup.html#aa49098473f42a2b38a7d753ed6f11c69", null ],
    [ "GetWindowSize", "class_add_database_button_type_popup.html#ab38db94d9ece140d239ea03642cf3761", null ],
    [ "OnGUI", "class_add_database_button_type_popup.html#ab1ce6eee985362a257345b830aba1f58", null ],
    [ "editorInstances", "class_add_database_button_type_popup.html#a6deb47258d4a99f314e782e50ed5f205", null ]
];