var searchData=
[
  ['editorinstances',['editorInstances',['../class_add_database_button_type_popup.html#a6deb47258d4a99f314e782e50ed5f205',1,'AddDatabaseButtonTypePopup']]]
];
