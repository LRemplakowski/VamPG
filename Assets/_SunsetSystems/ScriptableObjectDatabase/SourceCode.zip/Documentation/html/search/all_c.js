var searchData=
[
  ['name',['Name',['../class_my_lib_1_1_shared_1_1_database_1_1_database_asset.html#a5b0a5534c1e7c26d55a8cd03d9f7bd80',1,'MyLib.Shared.Database.DatabaseAsset.Name()'],['../class_asset_editor_window.html#a2f57c975b5cc93642244cb31996918d0',1,'AssetEditorWindow.Name()']]],
  ['numofentries',['NumOfEntries',['../class_my_lib_1_1_shared_1_1_database_1_1_database.html#aa2ec1fad1de1be169079f91058b3f434',1,'MyLib::Shared::Database::Database']]]
];
