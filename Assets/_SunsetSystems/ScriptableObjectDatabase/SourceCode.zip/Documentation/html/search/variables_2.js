var searchData=
[
  ['hiddenfiles',['hiddenFiles',['../class_main_database_collection.html#a3fdb62fd85d850f616474b3679e1f70f',1,'MainDatabaseCollection']]]
];
