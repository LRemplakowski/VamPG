var namespaces_dup =
[
    [ "MyLib", "namespace_my_lib.html", "namespace_my_lib" ]
];