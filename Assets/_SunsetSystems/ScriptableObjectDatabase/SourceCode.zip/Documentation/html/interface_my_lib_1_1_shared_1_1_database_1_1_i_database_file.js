var interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file =
[
    [ "AddNew", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#abfc2d0dca93794c9b21bc623f38cb84a", null ],
    [ "GetVisibility", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#afebc0b7c264a350b8acd3d3daa0dff0a", null ],
    [ "RemoveAtIndex", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#a513c5d646c10b6f8b4f4a66c3ef98487", null ],
    [ "SetId16", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#a368288d74066cc7fb61f7016cc17a6cb", null ],
    [ "DatabaseData", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#a183ae66e2daf849ba7606b1ff460740e", null ],
    [ "File", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#ac40f5cfafac5c4c6b53bfdd67794d3f2", null ],
    [ "IconAtlas", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#a997a9eba4ae2ec9e30db9733ca9273eb", null ],
    [ "IconTexture", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#ab75d6b8c88a7ef19409561de52fdcbd5", null ],
    [ "ID16", "interface_my_lib_1_1_shared_1_1_database_1_1_i_database_file.html#aa847749ff6f7bcc6456dd7b8ad4f7158", null ]
];