var namespace_my_lib_1_1_shared =
[
    [ "Database", "namespace_my_lib_1_1_shared_1_1_database.html", "namespace_my_lib_1_1_shared_1_1_database" ]
];